package com.cardy.flashcardServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlashcardServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlashcardServerApplication.class, args);
	}

}
